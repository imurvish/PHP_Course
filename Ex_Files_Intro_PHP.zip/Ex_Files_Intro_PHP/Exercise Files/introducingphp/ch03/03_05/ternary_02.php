<?php
$unit_cost = 20;

$wholesale_price = $unit_cost ?: 25;

echo $wholesale_price;
