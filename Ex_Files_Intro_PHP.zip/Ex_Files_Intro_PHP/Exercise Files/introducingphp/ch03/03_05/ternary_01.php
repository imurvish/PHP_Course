<?php
$answer = 40;

$result = ($answer == 42) ? 'The answer to the Ultimate Question of Life, the Universe, and Everything' : 'Keep calculating';

echo $result;