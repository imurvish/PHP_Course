<?php
// initialize counter
$i = 100;

do {
    // increment counter
    $i++;
    echo $i . '<br>';
} while ($i < 10);
