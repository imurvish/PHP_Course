<?php
$a = 5;
$b = 2;

echo -   $a . '<br>';
echo $a + $b . '<br>';
echo $a - $b . '<br>';
echo $a * $b . '<br>';
echo $a / $b . '<br>';

$degF = 98.6;
$degC = ($degF - 32) / 9 * 5;
echo $degC . '&degC';