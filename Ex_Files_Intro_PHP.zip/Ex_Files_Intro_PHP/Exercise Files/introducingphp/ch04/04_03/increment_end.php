<?php
$number = 5;
$number++;
echo $number . '<br>';
++$number;
echo $number . '<br>';
$result = $number++ * 2;
echo '$result is ' . $result . '<br>';
echo $number . '<br>';
$result = ++$number * 2;
echo '$result is ' . $result . '<br>';
echo $number . '<br>';