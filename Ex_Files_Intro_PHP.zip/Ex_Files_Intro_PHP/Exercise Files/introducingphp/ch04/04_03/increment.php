<?php
$number = 5;
$number++;
echo $number . '<br>';
++$number;
echo $number . '<br>';
