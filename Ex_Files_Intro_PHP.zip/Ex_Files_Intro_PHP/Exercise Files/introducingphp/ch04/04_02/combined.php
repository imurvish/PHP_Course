<?php
$total = 5;
$total = $total + 2;
echo $total;
