<?php

phpversion();