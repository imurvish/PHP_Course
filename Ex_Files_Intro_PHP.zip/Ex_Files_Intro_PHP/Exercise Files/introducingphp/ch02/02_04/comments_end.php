<?php
// This is a comment that is ignored by PHP

# This is also a comment

$firstName = 'David';  // This stores my first name

$lastName     =


    'Powers'


     ; # This stores my last name

/* This is a comment that spans multiple lines.
   It uses the same syntax as CSS. */

/*echo $firstName;
echo ' ';*/
echo $lastName;