<?php
//$characters = array('Arthur Dent', 'Ford Prefect', 'Zaphod Beeblebrox');
$characters = ['Arthur Dent', 'Ford Prefect', 'Zaphod Beeblebrox'];
//echo $characters;
$characters[] = 'Marvin';
$characters[] = 'Slartibartfast';


//print_r($characters);

echo $characters[1];