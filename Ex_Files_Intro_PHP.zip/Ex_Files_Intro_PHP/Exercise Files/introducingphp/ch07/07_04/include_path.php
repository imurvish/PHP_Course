<?php
echo get_include_path();
