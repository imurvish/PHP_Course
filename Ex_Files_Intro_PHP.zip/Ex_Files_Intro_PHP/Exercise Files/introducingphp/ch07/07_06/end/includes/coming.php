<article id="comingtoevent">
    <h2 class="highlight">Coming to the event?</h2>
    <h3>Check out our mobile site</h3>
    <p>Our mobile site contains schedules, and exhibit/ artist details, accessible simply by scanning QR codes located all around the venue exhibit halls.</p>
    <p><img src="<?= $siteroot; ?>/images/iphone.png" alt="iPhone"></p>
    <p><a class="link" href="#">Roux Mobile</a></p>
</article>

