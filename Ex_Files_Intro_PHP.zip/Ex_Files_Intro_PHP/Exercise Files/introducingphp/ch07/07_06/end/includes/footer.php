<footer>
    <div class="branding"> <img src="<?= $siteroot; ?>/images/ralogo_monogram.png" alt="Logo"> </div>
    <div class="description">Join over 500 hundred of the most creative and brilliant minds of art colleges all around the world for three days of lectures by world-renowned art scholars and artists.</div>
    <nav>
        <ol>
            <li><a href="http://rouxacademy.com/about/about.htm">About the Roux Academy</a></li>
            <li><a href="http://rouxacademy.com/privacy.htm">Privacy Policy</a></li>
            <li><a href="http://rouxacademy.com/index.htm">Visit our website</a></li>
        </ol>
    </nav>
</footer>

