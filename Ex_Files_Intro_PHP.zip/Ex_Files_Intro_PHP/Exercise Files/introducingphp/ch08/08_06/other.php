<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Target page</title>
    <link rel="stylesheet" href="styles.css" type="text/css">
</head>
<body>
<h1>The Redirect Worked!</h1>
<p>You should see this page if the redirect works.</p>
</body>
</html>