<?php
$submitted = true;
$message = 'Hi';

if($submitted) {
    $message = 'Thank you';
}

echo $message;