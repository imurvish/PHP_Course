<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Partially rendered page</title>
    <link href="styles.css" rel="stylesheet" type="text/css">
</head>
<body>
<div id="wrapper">
<?php require './includes/menu.php'; ?>
</div>
</body>
</html>