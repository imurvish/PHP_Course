<?php phpinfo();

